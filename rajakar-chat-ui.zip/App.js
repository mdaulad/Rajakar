import React, { useState } from "react";
import "./App.css";

function App() {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : theme === "dark" ? "green" : "light");
  };

  const bgClass =
    theme === "light"
      ? "bg-gray-100 text-gray-900"
      : theme === "dark"
      ? "bg-gray-900 text-white"
      : "bg-green-900 text-white";

  const bgImage =
    "https://i.ibb.co/pPX4Pgz/arabic-hadith-bg.png";

  return (
    <div className={`min-h-screen ${bgClass} relative`}>
      <div
        className="fixed inset-0 -z-10 bg-center bg-repeat opacity-10"
        style={{ backgroundImage: `url('${bgImage}')` }}
      />
      <header className="p-4 shadow-md flex justify-between">
        <h1 className="text-xl font-bold">Rajakar</h1>
        <button
          onClick={toggleTheme}
          className="bg-white text-black dark:bg-gray-700 dark:text-white px-3 py-1 rounded"
        >
          Change Theme
        </button>
      </header>
      <main className="p-4">
        <div className="border rounded-lg p-4 bg-white dark:bg-gray-800">
          <p className="text-gray-800 dark:text-gray-100">👋 স্বাগতম Rajakar এ!</p>
        </div>
      </main>
    </div>
  );
}

export default App;